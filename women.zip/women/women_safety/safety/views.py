from django.shortcuts import render, redirect
from django.core.mail import send_mail
from .models import EmergencyContact
import geocoder
import base64
from django.core.mail import EmailMessage
from django.conf import settings
from django.contrib import messages
import base64
from django.core.files.base import ContentFile
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import EmailMessage
import base64
from django.core.files.storage import FileSystemStorage
import os
from django.conf import settings



def index(request):
    emergency_contact = EmergencyContact.objects.first()
    phone_number = emergency_contact.phone if emergency_contact else '+919972450435'
    return render(request, 'index.html', {'phone_number': phone_number})
    
def add_contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        EmergencyContact.objects.create(name=name, email=email, phone=phone)
        return redirect('/')
    return render(request, 'add_contact.html')

def contact_list(request):
    contacts = EmergencyContact.objects.all()
    return render(request, 'contact_list.html', {'contacts': contacts})







import base64
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.mail import EmailMessage
from django.conf import settings
from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage

def capture_image(request):
    if request.method == 'POST':
        # Get the base64 image URL from the POST request
        image_url = request.POST.get('image_url')

        if image_url:
            # Process the base64 image data and save it
            format, imgstr = image_url.split(';base64,')
            ext = format.split('/')[1]
            imgdata = base64.b64decode(imgstr)
            file_name = 'captured_image.' + ext

            # Save the image to the filesystem
            fs = FileSystemStorage()
            saved_file = fs.save(file_name, ContentFile(imgdata))

            # Get the URL of the saved file
            file_url = fs.url(saved_file)

            # Redirect back to index with the image URL
            return redirect('index')  # Replace with any page you want after capture
    return render(request, 'capture_image.html')

import base64
from django.core.mail import EmailMessage
from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
from .models import EmergencyContact

def send_alert(request):
    if request.method == 'POST':
        # Extract latitude and longitude from the form
        latitude = request.POST.get('latitude')
        longitude = request.POST.get('longitude')

        # Validate location data
        if latitude and longitude:
            location_url = f"https://www.google.com/maps?q={latitude},{longitude}"
        else:
            location_url = "Location not available"
            print("Location data is missing or invalid.")  # Debug message

        # Extract base64 image data
        image_data = request.POST.get('imageData')
        image_bytes = None

        if image_data:
            try:
                if ',' in image_data:
                    image_bytes = base64.b64decode(image_data.split(',')[1])
            except Exception as e:
                print(f"Error decoding image: {e}")  # Debug message

        # Email preparation
        subject = "Emergency Alert"
        message = f"An emergency alert has been triggered.\n\nLocation: {location_url}\n\nPlease act immediately!"

        # Get all emergency contacts
        contacts = EmergencyContact.objects.all()

        # Send email to each contact
        for contact in contacts:
            email = EmailMessage(subject, message, settings.EMAIL_HOST_USER, [contact.email])

            # Attach the captured image if available
            if image_bytes:
                email.attach('captured_image.png', image_bytes, 'image/png')

            try:
                email.send()
                print(f"Email successfully sent to {contact.email}")  # Debug message
            except Exception as e:
                print(f"Error sending email to {contact.email}: {e}")  # Debug message

        # Success message
        messages.success(request, 'The emergency alert has been sent successfully!')
        return redirect('/')

    return render(request, 'index.html')


def camera_page(request):
    if request.method == "POST":
        # Save captured image
        captured_image = request.POST.get("image", None)
        if captured_image:
            # Handle saving the image or passing it to the alert email
            request.session["captured_image"] = captured_image
            return redirect("index")
    return render(request, "camera.html")
from django.shortcuts import get_object_or_404

def delete_contact(request, contact_id):
    # Fetch the contact by ID and delete it
    contact = get_object_or_404(EmergencyContact, id=contact_id)
    contact.delete()
    messages.success(request, "Contact deleted successfully.")
    return redirect('/contact-list/')



