from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.index, name='index'),
    path('add-contact/', views.add_contact, name='add_contact'),
    path('contact-list/', views.contact_list, name='contact_list'),
    path('send-alert/', views.send_alert, name='send_alert'),
    path('delete-contact/<int:contact_id>/', views.delete_contact, name='delete_contact'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
